export interface CityWeatherProps {
    name: string;
    temperature: number;
    weather: string;
    icon: string;
    id: number;
  }