export const config = {
  OPEN_WEATHER_MAP_API : "08eef4b90074e6d38726f67dca0722f3",
  firebaseConfig:{
    apiKey: "AIzaSyDUN3ZgbHmbCxtmwu-ubX7n6tKd8t_o8Po",
    authDomain: "softgen-test.firebaseapp.com",
    projectId: "softgen-test",
    storageBucket: "softgen-test.appspot.com",
    messagingSenderId: "181495755235",
    appId: "1:181495755235:web:5e04b5a57ad22b0cbd70d6",
  }
  
}
